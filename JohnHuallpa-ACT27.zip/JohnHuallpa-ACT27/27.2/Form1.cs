﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mensaje = comboBox1.Text + " ";
            if(checkBox1.Checked == true)
            {
                mensaje = mensaje + checkBox1.Text + " ";
            }
            if (checkBox2.Checked == true)
            {
                mensaje = mensaje + checkBox2.Text + " ";
            }
            if (checkBox3.Checked == true)
            {
                mensaje = mensaje + checkBox3.Text + " ";
            }
            label1.Text = mensaje;
        }
    }
}
