﻿/*
Actividad 2: Encuesta de Preferencias de Música
Problema:
Una aplicación quiere conocer los gustos musicales de los usuarios.
Requisitos:
● Mostrar un ComboBox con 5 géneros musicales distintos.
● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
&quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
seleccionado y las actividades marcadas.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._2
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
