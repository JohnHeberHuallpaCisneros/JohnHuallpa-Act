﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string servicios = " ";
            if(checkBox1.Checked == true)
            {
                servicios = servicios + checkBox1.Text + " ";
            }
            if (checkBox2.Checked == true)
            {
                servicios = servicios + checkBox2.Text + " ";
            }
            label1.Text = $"Plan elegido: {comboBox1.Text} Servicios: {servicios}";
        }
    }
}
