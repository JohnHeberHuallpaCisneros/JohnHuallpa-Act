﻿/*
Actividad 5: Configuración de Suscripción
Problema:
Una aplicación ofrece distintos niveles de suscripción.
Requisitos:
● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
técnico&quot;, &quot;Acceso anticipado&quot;).
● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
plan y los servicios elegidos.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._5
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
