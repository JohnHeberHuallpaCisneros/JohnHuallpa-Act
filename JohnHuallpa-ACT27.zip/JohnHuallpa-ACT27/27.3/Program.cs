﻿/*
Actividad 3: Elección de Paquete de Viaje
Problema:
Una agencia de viajes ofrece distintos tipos de paquetes turísticos.
Requisitos:
● Usar tres RadioButton para seleccionar el destino principal: &quot;Playa&quot;, &quot;Montaña&quot; o
&quot;Ciudad&quot;.

● Agregar un ComboBox para elegir la duración del viaje (ejemplo: &quot;3 días&quot;, &quot;7 días&quot;,
&quot;15 días&quot;).
● Un botón &quot;Confirmar&quot; debe mostrar en un Label la opción seleccionada.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._3
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
