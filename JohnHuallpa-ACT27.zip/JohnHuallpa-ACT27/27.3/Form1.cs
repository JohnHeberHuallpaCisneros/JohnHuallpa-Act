﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string zona = "";
            if (radioButton1.Checked == true)
            {
                zona = radioButton1.Text;
            }
            if (radioButton2.Checked == true)
            {
                zona = radioButton2.Text;
            }
            if (radioButton3.Checked == true)
            {
                zona = radioButton3.Text;
            }
            label1.Text = $"{zona} {comboBox1.Text}";
        }
    }
}
