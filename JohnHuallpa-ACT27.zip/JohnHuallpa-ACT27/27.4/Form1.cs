﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string recomendacion = "";
                if(radioButton1.Checked == true)
            {
                recomendacion = radioButton1.Text;
            }
            if (radioButton2.Checked == true)
            {
                recomendacion = radioButton2.Text;
            }
            label1.Text = $"Opinión recibida: {textBox1.Text} - Recomendación: {recomendacion}";
        }
    }
}
