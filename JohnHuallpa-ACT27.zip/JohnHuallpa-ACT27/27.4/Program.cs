﻿/*
Actividad 4: Sistema de Opinión sobre un Producto
Problema:
Se quiere crear un formulario de opinión para un producto.
Requisitos:
● Un Label debe indicar: &quot;Escribe tu opinión&quot;.
● Incluir un TextBox grande (multilínea) donde el usuario escriba su comentario.
● Dos RadioButton deben permitir seleccionar sí recomiendan el producto: &quot;Sí&quot; o &quot;No&quot;.
● Al hacer clic en el botón &quot;Enviar&quot;, se debe mostrar un Label con el mensaje: &quot;Opinión
recibida: [texto] – Recomendación: [Sí/No]&quot;.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _27._4
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
