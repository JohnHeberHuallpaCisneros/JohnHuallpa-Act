﻿/*
Elaborar una interfaz gráfica que muestre una calculadora (utilizar
objetos de la clase Button y un objeto de la clase Label donde se
muestra el valor ingresado), tener en cuenta que solo se debe
implementar la interfaz y la carga de un valor de hasta 12 dígitos.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25._4
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
