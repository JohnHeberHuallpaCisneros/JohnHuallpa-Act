﻿/*
Crear una aplicación que muestre en 6 objetos de la clase Label con
algunos nombres de controles visuales contenidos en la pestaña de
&quot;controles comunes&quot; del cuadro de herramientas
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25._3
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
