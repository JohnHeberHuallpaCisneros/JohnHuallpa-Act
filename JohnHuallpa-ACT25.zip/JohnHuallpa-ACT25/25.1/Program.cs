﻿/*
1. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
objetos de la clase Button y un objeto de la clase TextBox donde se
mostrarían los resultados y se cargarían los datos), tener en cuenta que
solo se debe implementar la interfaz y no la funcionalidad de una
calculadora.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25._1
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
