﻿/*
Disponer 7 objetos de la clase Button con los días de la semana. Fijar en
los atributos Text de cada botón los días de la semana. Al presionar un
botón mostrar en un objeto de la clase Label el día seleccionado.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25._2
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
