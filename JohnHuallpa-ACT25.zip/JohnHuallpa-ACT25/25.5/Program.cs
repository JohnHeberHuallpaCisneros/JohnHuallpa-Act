﻿/*
Solicitar el ingreso de una clave de hasta 10 caracteres en un control de
tipo TextBox (inicializar la propiedad MaxLength con el valor 10)
Mostrar en un cuadro de mensajes la clave ingresada al presionar un
botón.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _25._5
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
