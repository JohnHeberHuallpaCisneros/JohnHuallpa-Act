﻿/*
3. Gestor de Tareas Simplificado (Investigación: ListBox)
● Investigación: Investigar el control ListBox (propiedad Items, métodos Add() y
RemoveAt()). Explicar brevemente su funcionamiento e incluir un ejemplo resuelto.
● Consigna: Armar una interfaz con un TextBox, un Button &quot;Agregar&quot;, un Button
&quot;Eliminar&quot; y un ListBox. Permitir añadir el texto tipeado a la lista y borrar el elemento
que el usuario seleccione.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _28._3
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
