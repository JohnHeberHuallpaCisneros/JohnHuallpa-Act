﻿/*
5. Visor Dinámico de Imágenes (Investigación: PictureBox)
● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
SizeMode.
● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _28._5
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
