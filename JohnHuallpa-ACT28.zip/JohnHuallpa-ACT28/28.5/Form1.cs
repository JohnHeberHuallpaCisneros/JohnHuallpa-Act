﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _28._5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pictureBox1.ImageLocation = "Images/noelling.png";
                pictureBox1.Load();
            }

            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = "Images/Apisonaflor.jpg";
                pictureBox1.Load();
            }

            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = "Images/Wavedashing.png";
                pictureBox1.Load();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Noelling");
            comboBox1.Items.Add("Apisonaflor");
            comboBox1.Items.Add("Wavedashing");
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }
    }
}
