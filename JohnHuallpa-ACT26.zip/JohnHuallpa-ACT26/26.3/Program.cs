﻿/*
Solicitar el ingreso del nombre de una persona y seleccionar de un control
ComboBox un país. Al presionar un botón mostrar en la barra del título del
Form el nombre ingresado y el país seleccionado.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26._3
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
