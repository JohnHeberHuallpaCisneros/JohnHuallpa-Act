﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Argentina");
            comboBox1.Items.Add("Perú");
            comboBox1.Items.Add("Japón");
            comboBox1.Items.Add("Chile");
            comboBox1.Items.Add("Brasil");
            comboBox1.Items.Add("Ecuador");
            comboBox1.Items.Add("Colombia");
            comboBox1.Items.Add("México");
            comboBox1.Items.Add("Disparos unidos");
            comboBox1.Items.Add("Uruguay");
            comboBox1.Items.Add("Paraguay");
            comboBox1.Items.Add("España");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = $"{textBox1.Text} {comboBox1.Text}";
        }
    }
}
