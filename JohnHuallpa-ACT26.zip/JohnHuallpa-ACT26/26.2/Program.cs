﻿/*
Permitir el ingreso de dos números en controles de tipo TextBox y mediante
dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
operación.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26._2
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
