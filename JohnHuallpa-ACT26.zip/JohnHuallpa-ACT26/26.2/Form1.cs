﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _26._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                int valor1 = int.Parse(textBox1.Text);
                int valor2 = int.Parse(textBox2.Text);
                int suma = valor1 + valor2;
                Text = suma.ToString();
            }
            if (radioButton2.Checked == true)
            {
                int valor1 = int.Parse(textBox1.Text);
                int valor2 = int.Parse(textBox2.Text);
                int resta = valor1 - valor2;
                Text = resta.ToString();
            }
        }
    }
}
