﻿/*
7. Selector de Color con Valores Numéricos (Investigación:
NumericUpDown)
● Investigación: Explicar el control NumericUpDown (propiedades Minimum,
Maximum y Value) y sus ventajas frente al TextBox.
● Consigna: Crear tres NumericUpDown restringidos entre 0 y 255 (Rojo, Verde,
Azul). Un Button cambiará la propiedad BackColor del Form aplicando
Color.FromArgb().
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29._2
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
