﻿/*
9. Cálculo de Edad (Investigación: DateTimePicker)
● Investigación: Investigar el control DateTimePicker (propiedad Value de tipo
DateTime).
● Consigna: Permitir que el usuario elija su fecha de nacimiento. Mediante un Button,
calcular los años cumplidos restando la fecha elegida con DateTime.Now.Year y
mostrarlo en un Label.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29._4
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
