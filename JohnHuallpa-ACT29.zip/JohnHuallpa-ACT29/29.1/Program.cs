﻿/*
6. Simulador de Carrito de Compras
● Consigna: Disponer tres CheckBox con productos y precios fijos. Un Button
&quot;Calcular Total&quot; debe evaluar los controles seleccionados (Checked == true), sumar
sus costos y mostrar el monto final en un Label.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29._1
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
