﻿/*
8. Validador de Credenciales y Formato
● Consigna: Solicitar usuario y contraseña mediante TextBox (usando
UseSystemPasswordChar = true). Un CheckBox &quot;Acepto términos&quot; debe habilitar
(Enabled = true) el Button &quot;Ingresar&quot;. Si la clave coincide con &quot;admin123&quot;, mostrar
éxito en una Label; de lo contrario, mostrar advertencia.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29._3
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
