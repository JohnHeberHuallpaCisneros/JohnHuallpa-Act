﻿/*
10. Administrador de Roles y Permisos
● Consigna: Incluir un ComboBox con opciones: &quot;Administrador&quot;, &quot;Editor&quot; e &quot;Invitado&quot;.
En el evento SelectedIndexChanged, modificar dinámicamente la propiedad Enabled
de tres CheckBox (&quot;Crear&quot;, &quot;Modificar&quot;, &quot;Eliminar&quot;) según el perfil elegido.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _29._5
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
